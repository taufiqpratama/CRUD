<?php 
class home extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this-> load -> model("homemodel");
		$this-> load -> helper('url');
	}
	
	function index (){
	$data['t_mhs'] = $this-> homemodel-> tampil_data()-> result();
	$this -> load -> view("v_tampil",$data);
	}

	function tambah(){
		$this-> load -> view ('homeview');
	}

	function tambah_aksi(){
		$nim = $this-> input -> POST('nim');
		$nama = $this-> input -> POST('nama');
		$jurusan = $this-> input -> POST('jurusan');
		$fakultas = $this-> input -> POST('fakultas');
		$alamat = $this-> input -> POST('alamat');
		$data = array(
			'nim' => $nim,
			'nama' => $nama,
			'jurusan' => $jurusan,
			'fakultas' => $fakultas,
			'alamat' => $alamat );
		$this-> homemodel -> input_data($data,'t_mhs');
		redirect('home/index');
	}
	function hapus($id){
		$where = array('id' => $id);
		$this-> homemodel ->hapus_data($where,'t_mhs');
		redirect('home/index');
	}
	function edit($id){
	$where = array('id'=> $id);
	$data['t_mhs'] = $this-> homemodel -> edit_data($where,'t_mhs') ->result();
	$this-> load ->view('v_edit',$data);
	}
	function update(){
	$id = $this->input->post('id');
	$nim = $this->input->post('nim');
	$nama = $this->input->post('nama');
	$jurusan = $this->input->post('jurusan');
	$fakultas = $this->input->post('fakultas');
	$alamat = $this->input->post('alamat');
	
	$data = array(
		'nim' => $nim,
		'nama' => $nama,
		'jurusan' => $jurusan,
		'fakultas' => $fakultas,
		'alamat' => $alamat
	);
 
	$where = array(
		'id' => $id
	);
 
	$this-> homemodel ->update_data($where,$data,'t_mhs');
	redirect('home/index');
	}
}
 ?>