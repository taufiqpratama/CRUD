<!DOCTYPE html>
<html>
<head>
	<base href="<?=base_url()?>">
	<meta charset="UTF-8">
	<title>Input Data Mahasiswa</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<center>
		<h1>Data Mahasiswa<br>Universitas Pendidikan Indonesia</h1>
		<h3>Tambahkan Data</center>
<form action="<?php base_url();?>tambah_aksi" method="post">
		<table style="margin:20px auto;">
			<tr>
				<td>Nim</td>
				<td><input type="text" name="nim"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr>
				<td>Jurusan</td>
				<td><input type="text" name="jurusan"></td>
			</tr>
			<tr>
				<td>Fakultas</td>
				<td><input type="text" name="fakultas"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="textarea" name="alamat" style="width:170px;height: 100px"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Tambah"></td>
			</tr>
		</table>
	</form>	
</body>
</html>