<!DOCTYPE html>
<html>
<head>
	<title>Membuat CRUD dengan CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<center>
		<h1>Data Mahasiswa<br>Universitas Pendidikan Indonesia</h1>
		<h3>Edit Data</h3>
	</center>
	<?php foreach($t_mhs as $u){ ?>
	<form action="<?php echo base_url(). 'home/update'; ?>" method="post">
		<table style="margin:20px auto;">
			<tr>
				<td>Nim</td>
				<td>
					<input type="hidden" name="id" value="<?php echo $u->id ?>">
					<input type="text" name="nim" value="<?php echo $u->nim ?>">
				</td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama" value="<?php echo $u->nama ?>"></td>
			</tr>
			<tr>
				<td>Jurusan</td>
				<td><input type="text" name="jurusan" value="<?php echo $u->jurusan ?>"></td>
			</tr>
			<tr>
				<td>Fakultas</td>
				<td><input type="text" name="fakultas" value="<?php echo $u->fakultas ?>"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="alamat" value="<?php echo $u->alamat ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="simpan"></td>
			</tr>
		</table>
	</form>	
	<?php } ?>
</body>
</html>