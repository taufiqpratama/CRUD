<!DOCTYPE html>
<html>
<head>
	<title>Data Mahasiswa</title>

</head>
<body>
	<center><h1>Data Mahasiwa<br>Universitas Pendidikan Indonesia </h1></center>
	<center><?php echo anchor('home/tambah','Tambah Data'); ?></center>
	<table style="margin:20px auto;" border="1">
		<tr>
			<th>No</th>
			<th>Nim</th>
			<th>Nama</th>
			<th>Jurusan</th>
			<th>Fakultas</th>
			<th>Alamat</th>
			<th>Action</th>
		</tr>
		<?php 
		$no = 1;
		foreach($t_mhs as $u){ 
		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $u->nim ?></td>
			<td><?php echo $u->nama ?></td>
			<td><?php echo $u->jurusan ?></td>
			<td><?php echo $u->fakultas ?></td>
			<td><?php echo $u->alamat ?></td>
			<td>
			      <?php echo anchor('home/edit/'.$u->id,'Edit'); ?>
                              <?php echo anchor('home/hapus/'.$u->id,'Hapus'); ?>
			</td>
		</tr>
		<?php } ?>
	</table>
</body>
</html>